import socket
import pickle
import threading
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

HOST = socket.gethostbyname(socket.gethostname())
__PORT__ = 1010

PC = {'192.168.102.249':'Aayush','192.168.102.250':'Sarva','192.168.102.248':'Harish',
      '192.168.102.235':'Debajyoti','192.168.102.247':'Darsh','192.168.102.246':'Smarak',
      '192.168.102.245':'Kundan','192.168.102.240':'Savith','192.168.102.238':'Karthik',
      '192.168.102.242':'Pranav','192.168.102.234':'Padmanav','192.168.102.237':'Koushik',
      '192.168.102.244':'Mahishrit','192.168.102.233':'Piyush','192.168.0.110':'Kousbha'}

lobby = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
random_user = 1
try:
    lobby.bind((HOST, __PORT__))
    print(f'Created Lobby {HOST} {__PORT__}')
except Exception as e:
    print('Error creating Lobby:', e)
    exit(1)
lobby.listen()

class Room:
    codes = []
    allrooms = {}

    def __init__(self, PORT):
        global HOST
        self.PORT = PORT
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.server.bind((HOST, PORT))
            print(f'Created server {HOST} {PORT}')
        except Exception as e:
            print(f'Error Creating Server {HOST} {PORT}:', e)
        self.server.listen()
        self.run = True
        self.allclients = []
        self.alladdress = {}
        self.chathistory = ''
        Room.allrooms[PORT] = self
        Room.codes.append(PORT)
        threading.Thread(target=self.getclient).start()

    def getclient(self):
        while self.run:
            try:
                client, address = self.server.accept()
                self.alladdress[client] = address
                print(f'Connected {PC.get(address[0], address[0])} to {self.PORT}')
                self.allclients.append(client)
                self.update_online_players()
                self.SEND(f'server:{PC.get(address[0], address[0])} has joined.')
                threading.Thread(target=self.RECIEVE, args=(client,)).start()
            except Exception as e:
                print(f'Error accepting client: {e}')

    def update_online_players(self):
        onlineplayers = 'online:'
        for clts in self.allclients:
            onlineplayers = f'{onlineplayers}{PC.get(self.alladdress[clts][0], self.alladdress[clts][0])},'
        self.SEND(onlineplayers)

    def SEND(self, message=str):
        self.chathistory = f'{self.chathistory}\n{message}'
        for client in self.allclients:
            try:
                client.sendall(pickle.dumps(f'{message}'))
            except:
                self.allclients.remove(client)

    def RECIEVE(self, client):
        while self.run:
            try:
                message = pickle.loads(client.recv(2048))
                if message:
                    self.SEND(f'{PC.get(self.alladdress[client][0], self.alladdress[client][0])} : {message}')
            except:
                self.allclients.remove(client)
                self.SEND(f'{PC.get(self.alladdress[client][0], self.alladdress[client][0])} left the server.')
                self.update_online_players()
                break

    def END(self):
        self.run = False
        self.SEND(f'SERVER: Closing due to maintenance.')
        self.allclients.clear()
        del self

    def history(self):
        return self.chathistory

def commands(client, address):
    global random_user;run=True
    while run:
        try:
            if address[0] not in PC.keys():
                PC[address[0]] = 'User-' + str(random_user)
                random_user += 1
            while True:
                try:
                    code = pickle.loads(client.recv(2048))
                    print(f'Request {PC.get(address[0], address[0])} to PORT {code}')
                except:
                    print(f'Disconnected {address[0]}')
                    client.close();run=False;break
                if code in Room.codes:
                    client.send(pickle.dumps(True))
                    print(f'Connecting {PC.get(address[0], address[0])} to {code}')
                    break
                else:
                    client.send(pickle.dumps(False))
                    try:
                        message = pickle.loads(client.recv(2048))
                    except:
                        message = True
                    if message:
                        Room(code)
                        break
                    else:
                        client.send(pickle.dumps("Error"))
                        break
        except:client.close()
def RunLobby():
    while True:
        try:
            client, address = lobby.accept()
            threading.Thread(target=commands, args=(client, address)).start()
        except Exception as e:
            print(f'Error in lobby: {e}')
            break

def chat(message=str):
    for code in Room.codes:
        Room.allrooms[code].SEND(message)

class AdminUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Admin Control Panel")

        self.main_frame = ttk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.tab_control = ttk.Notebook(self.main_frame)
        self.tab_control.pack(fill=tk.BOTH, expand=True)

        self.server_tabs = {}
        self.user_listbox = tk.Listbox(self.main_frame, selectmode=tk.SINGLE)

        self.create_command_frame()
        self.update_server_list()

        threading.Thread(target=self.update_server_tabs).start()

    def create_command_frame(self):
        command_frame = ttk.Frame(self.main_frame)
        command_frame.pack(fill=tk.X, side=tk.BOTTOM)

        kick_button = ttk.Button(command_frame, text="Kick User", command=self.kick_user)
        kick_button.pack(side=tk.LEFT)

        broadcast_button = ttk.Button(command_frame, text="Broadcast", command=self.broadcast_message)
        broadcast_button.pack(side=tk.LEFT)

        refresh_button = ttk.Button(command_frame, text="Refresh Users", command=self.refresh_user_list)
        refresh_button.pack(side=tk.LEFT)

        self.user_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def update_server_list(self):
        for port in Room.codes:
            if port not in self.server_tabs:
                tab = ttk.Frame(self.tab_control)
                self.tab_control.add(tab, text=f"Port {port}")
                chat_display = tk.Text(tab, state=tk.DISABLED, wrap=tk.WORD)
                chat_display.pack(fill=tk.BOTH, expand=True)
                self.server_tabs[port] = chat_display

    def update_server_tabs(self):
        while True:
            self.update_server_list()
            for port, chat_display in self.server_tabs.items():
                chat_display.config(state=tk.NORMAL)
                chat_display.delete(1.0, tk.END)
                chat_display.insert(tk.END, Room.allrooms[port].history())
                chat_display.config(state=tk.DISABLED)
            self.root.after(1000, self.update_server_list)

    def kick_user(self):
        port = self.get_selected_port()
        if port is None:
            messagebox.showinfo("Error", "No server selected")
            return

        selected_user = self.user_listbox.get(tk.ACTIVE)
        if not selected_user:
            messagebox.showinfo("Error", "No user selected")
            return

        user_ip = self.get_ip_from_name(selected_user)
        if user_ip is None:
            messagebox.showinfo("Error", "User not found")
            return

        room = Room.allrooms.get(port)
        if room:
            for client, address in room.alladdress.items():
                if address[0] == user_ip:
                    room.allclients.remove(client)
                    room.SEND(f'{PC[user_ip]} was kicked from the server.')
                    self.refresh_user_list()
                    break

    def broadcast_message(self):
        message = simpledialog.askstring("Input", "Enter message to broadcast:")
        if message:
            chat(f'ADMIN: {message}')

    def refresh_user_list(self):
        self.user_listbox.delete(0, tk.END)
        port = self.get_selected_port()
        if port is not None:
            room = Room.allrooms.get(port)
            if room:
                for client in room.allclients:
                    user_name = PC[room.alladdress[client][0]]
                    self.user_listbox.insert(tk.END, user_name)

    def get_ip_from_name(self, name):
        for ip, user_name in PC.items():
            if user_name == name:
                return ip
        return None

    def get_selected_port(self):
        tab_index = self.tab_control.index(self.tab_control.select())
        tab_text = self.tab_control.tab(tab_index, "text")
        if tab_text.startswith("Port "):
            return int(tab_text.split(" ")[1])
        return None

def main():
    threading.Thread(target=RunLobby).start()

    root = tk.Tk()
    admin_ui = AdminUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
