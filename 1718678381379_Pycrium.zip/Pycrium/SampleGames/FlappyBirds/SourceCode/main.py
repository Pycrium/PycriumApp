import pygame ,random
run = True ; cheat = False
win_x,win_y=(288*2,512)
class character():
    allobjects=[]
    BlueBird = [pygame.image.load(r'..\Assets\bluebird-downflap.png'),
                pygame.image.load(r'..\Assets\bluebird-midflap.png'),
                pygame.image.load(r'..\Assets\bluebird-upflap.png'),]
    RedBird = [pygame.image.load(r'..\Assets\redbird-downflap.png'),
                pygame.image.load(r'..\Assets\redbird-midflap.png'),
                pygame.image.load(r'..\Assets\redbird-upflap.png'),]
    YellowBird = [pygame.image.load(r'..\Assets\yellowbird-downflap.png'),
                pygame.image.load(r'..\Assets\yellowbird-midflap.png'),
                pygame.image.load(r'..\Assets\yellowbird-upflap.png'),]
    Color = [BlueBird,RedBird,YellowBird]
    def __init__(self,root,x=int,y=int):
        global win_x ,win_y
        self.win_x = win_x ; self.win_y = win_y
        self.ImagesList =  character.Color[random.randint(0,2)]
        self.Part = (self.ImagesList[0]).get_rect()
        self.Part.midbottom = x,y
        self.JumpCheck = False
        self.JumpPower = 0
        self.Speed = 0
        self.AnimationNumber = 0
        self.root = root
        self.score = 0
        character.allobjects.append(self)
    def GoJump(self):
        self.JumpCheck=True ; self.JumpPower=-2; self.AnimationNumber=0
    def move(self):
        self.Control()
        if self.JumpCheck:
            self.Part.y+=(2*self.JumpPower-1)
        background.move(-2)
        self.AnimationNumber+=0.1
        self.JumpPower+=0.25
        self.Draw()
    def Draw(self):self.root.blit(self.ImagesList[int(self.AnimationNumber)%len(self.ImagesList)],self.Part)
    def Control(self):
        if pygame.key.get_pressed()[pygame.K_SPACE]:
            self.GoJump()
        if pygame.key.get_pressed()[pygame.K_BACKSLASH]:
            global cheat 
            cheat = True
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
            cheat = False
    def GameOver(self):
        if self.Part.y>win_y or self.Part.y<0:return False
        return True
class background:
    number = 0
    allobjects = []
    def __init__(self,root,Image):
        global win_x,win_y; self.root = root
        self.Image = Image
        self.Part = self.Image.get_rect()
        self.Part.topleft = (background.number*288,0)
        background.number+=1 ; background.allobjects.append(self)
    def move(x=int):
        for obj in background.allobjects:
            obj.Part.x = ((obj.Part.x+win_x+x))%(win_x*(background.number)-win_x*2)-win_x
    def Draw():
        for obj in background.allobjects:
            obj.root.blit(obj.Image,obj.Part)
class obstacle():
    allobjects = []
    root = pygame.surface.Surface
    ScoreImage = {'0':pygame.image.load(r'..\Assets\0.png'),
                '1':pygame.image.load(r'..\Assets\1.png'),
                '2':pygame.image.load(r'..\Assets\2.png'),
                '3':pygame.image.load(r'..\Assets\3.png'),
                '4':pygame.image.load(r'..\Assets\4.png'),
                '5':pygame.image.load(r'..\Assets\5.png'),
                '6':pygame.image.load(r'..\Assets\6.png'),
                '7':pygame.image.load(r'..\Assets\7.png'),
                '8':pygame.image.load(r'..\Assets\8.png'),
                '9':pygame.image.load(r'..\Assets\9.png')}
    hundredth = ScoreImage['0'].get_rect()
    tenth = ScoreImage['0'].get_rect()
    ones = ScoreImage['0'].get_rect()
    hundredth.topleft = (10,10)
    tenth.topleft = (10+27,10)
    ones.topleft = (10+27*2,10)
    def __init__(self,root):
        obstacle.root = root
        self.UpImage = pygame.image.load(r'..\Assets\pipe-green-down.jpg')
        self.DownImage = pygame.image.load(r'..\Assets\pipe-green-up.png')
        self.Up = self.UpImage.get_rect()
        self.Down = self.UpImage.get_rect()
        x=win_x+30;y=random.randint(150,300)
        self.Up.bottomleft = (x,y)
        self.Down.topleft = (x,y+150)
        self.root = root
        
        obstacle.allobjects.append(self)
    def move(x=int):
        for obj in obstacle.allobjects:
            obj.Up.x += x
            obj.Down.x += x
            obj.root.blit(obj.UpImage,obj.Up)
            obj.root.blit(obj.DownImage,obj.Down)
            if obj.Up.x>=90+x and obj.Up.x<90:
                character.allobjects[0].score +=1
            if obj.Up.x<-50:
                obstacle.allobjects.pop(obstacle.allobjects.index(obj))
                del obj 
    def UpdateScore():
        score = str(character.allobjects[0].score)
        while len(score)<3:score='0'+score
        obstacle.root.blit(obstacle.ScoreImage[score[0]],obstacle.hundredth)
        obstacle.root.blit(obstacle.ScoreImage[score[1]],obstacle.tenth)
        obstacle.root.blit(obstacle.ScoreImage[score[2]],obstacle.ones)
    def Draw():
        for obj in obstacle.allobjects:
            obj.root.blit(obj.UpImage,obj.Up)
            obj.root.blit(obj.DownImage,obj.Down)
        obstacle.UpdateScore()
    def GameOver():
        run = True
        for player in character.allobjects:
            if not(run):break
            for obj in obstacle.allobjects:
                if pygame.Rect.colliderect(player.Part,obj.Up):
                    run = False ;break
                if pygame.Rect.colliderect(player.Part,obj.Down):
                    run = False ;break
        return run
win_x,win_y=(288*2,512)
screen = pygame.display.set_mode((win_x,win_y))
pygame.display.set_caption('Flappy Birds')
Clock = pygame.time.Clock()
FPS = 80
while True:
    background.number=0
    player = character(x=100,y=300,root=screen)
    if random.randint(0,1)==0:
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-day.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-day.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-day.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-day.png'))
    else:
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-night.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-night.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-night.png'))
        background(root=screen,Image=pygame.image.load(r'..\Assets\background-night.png'))
    num=1;rep=150
    cheat = False
    while (obstacle.GameOver() and player.GameOver() and run) or cheat :
        if num%(rep//1) == 1:
            num = 1
            if rep>30:rep-=0.5
            obstacle(screen)
        Clock.tick(FPS)
        for et in pygame.event.get():
            if et.type == pygame.QUIT:
                run = False   
        background.Draw()
        obstacle.move(-3)
        obstacle.Draw()
        player.move()
        num+=1
        FPS = 80 + player.allobjects[0].score/10 
        pygame.display.update()
    Image_GameOver = pygame.image.load(r'..\Assets\gameover.png')
    Rect_GameOver = Image_GameOver.get_rect()
    Rect_GameOver.center = win_x//2,win_y//2
    count = 25
    while run:
        count-=10
        Clock.tick(FPS)
        for et in pygame.event.get():
            if et.type == pygame.QUIT:
                run = False
        background.Draw()
        obstacle.Draw()
        player.Draw()
        screen.blit(Image_GameOver,Rect_GameOver)
        pygame.display.update()
        if pygame.key.get_pressed()[pygame.K_SPACE] and count<0:break           
    for allclass in [character,background,obstacle]:
        for obj in allclass.allobjects:
            del obj
        allclass.allobjects.clear()
    if run == False:break
     