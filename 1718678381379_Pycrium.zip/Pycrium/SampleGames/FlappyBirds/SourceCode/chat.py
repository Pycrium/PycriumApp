import socket, pickle, threading, os
HOST =  '192.168.0.110'
__PORT__ = 1010
lobby = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
lobby.connect((HOST,__PORT__))

while True:
    print('Create Or Join Servers(COMMON SERVER - 1234)')
    CODE = int(input('Enter pass number:'))
    lobby.send(pickle.dumps(CODE))
    message = pickle.loads(lobby.recv(2048))
    if bool(message):
        client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        print(f'Trying to connect to {HOST} {CODE}')
        client.connect((HOST,CODE))
        print(f'Success') 
        break      
    else: 
        message=input(f'Server doesnt exist.To create server with pass {CODE} enter True:')
        if message:
            try:
                lobby.send(pickle.dumps(True))
                client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
                print(f'Trying to connect to {HOST} {CODE}')
                client.connect((HOST,CODE))
                print(f'Success') 
                break 
            except:
                print('ERROR.Try retrying same pass') 
lobby.send(pickle.dumps('Success'))          
print('Starting')  
def receive():
    while True: 
        message = pickle.loads(client.recv(2**20))
        os.system('cls')
        print(message)
def send():
    while True:
        client.sendall(pickle.dumps(input(':')))
threading.Thread(target=receive).start()
threading.Thread(target=send).start()