import socket, pickle, threading
HOST = socket.gethostbyname(socket.gethostname())
__PORT__ = 1010
PC = {'192.168.102.249':'Aayush','192.168.102.250':'Sarva','192.168.102.248':'Harish','192.168.102.235':'Debajyoti','192.168.102.247':'Darsh','192.168.102.246':'Smarak','192.168.102.245':'Kundan','192.168.102.240':'Savith','192.168.102.238':'Karthik','192.168.102.242':'Pranav','192.168.102.234':'Padmanav','192.168.102.237':'Koushik','192.168.102.244':'Mahishrit','192.168.102.233':'Piyush','192.168.0.110':'Kousbha'}
lobby = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
try:
    lobby.bind((HOST,__PORT__))
    print(f'Created Lobby {HOST} {__PORT__}')
except:
    print('Error creating Lobby')
lobby.listen()
class room:
    codes = []
    allrooms = {}
    def __init__(self,PORT=int):
        global HOST ; self.PORT = PORT
        self.server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            self.server.bind((HOST,PORT))
            print(f'Created server {HOST} {PORT}')
        except:
            print(f'Error Creating Server {HOST} {PORT}')
        self.server.listen()
        self.run = True ; self.allclients = []; self.alladdress = {}
        self.chathistory = ''
        room.allrooms[PORT] = self
        room.codes.append(PORT)
        threading.Thread(target=self.getclient).start()
    def getclient(self):
        while self.run:
            client,self.alladdress[client] = self.server.accept()
            print(f'Connected {PC[(self.alladdress[client])[0]]} to {self.PORT}')
            self.allclients.append(client)
            onlineplayers = 'online:'
            for clts in self.allclients:
                onlineplayers = f'{onlineplayers}{PC[self.alladdress[clts][0]]},'
            self.SEND(onlineplayers)
            self.SEND(f'server:{PC[(self.alladdress[client])[0]]} has joined.')
            threading.Thread(target=self.RECIEVE,args=(client,)).start()
    def SEND(self,message=str):
        self.chathistory = (f'{self.chathistory}\n{message}')
        for client in self.allclients:
            client.sendall(pickle.dumps(f'{self.chathistory}'))
    def RECIEVE(self,client):
        while self.run:
            try:message = pickle.loads(client.recv(2048))
            except:
                self.allclients.pop(self.allclients.index(client))
                self.SEND(f'{PC[self.alladdress[client][0]]} left the server.')
                onlineplayers = 'Online:'
                for clts in self.allclients:
                    onlineplayers = f'{onlineplayers}{PC[self.alladdress[clts][0]]},'
                self.SEND(onlineplayers)
                break
            if message != '':
                self.SEND(f'{PC[(self.alladdress[client])[0]]} : {message}')
    def END(self):
        self.run=False
        self.SEND(f'SERVER: Closing due to maintainance.')
        self.allclients.clear()
        del self
    def history(self):
        print(self.chathistory)
def commands(client,address):
    run = True
    while True:
        try:
            code = pickle.loads(client.recv(2048))
            print(f'Request {PC[address[0]]} to PORT {code}')
        except:
            print(f'Disconnected {PC[address[0]]}');break
        if code in room.codes:
            client.send(pickle.dumps(True));run=False
            print(f'Connecting {PC[address[0]]} to {code}')
        else:
            client.send(pickle.dumps(False))
            try:message = pickle.loads(client.recv(2048))
            except:message=  True
            if message:
                try:room(code);run=False
                
                except:print(f'Error occured while creating server {code}')
            else:client.send(pickle.dumps("Error"));run=False
def RunLobby():
    while True:
        client,address = lobby.accept()
        threading.Thread(target=commands,args=(client,address)).start()
def chat(str=str):
    for codes in room.codes:
        room.allrooms[codes].SEND(str)
threading.Thread(target=RunLobby,args=tuple()).start()
def cmd():
    while True:
        try:eval(input())
        except:print('Invalid cmd')
threading.Thread(target=cmd,args=tuple()).start()






