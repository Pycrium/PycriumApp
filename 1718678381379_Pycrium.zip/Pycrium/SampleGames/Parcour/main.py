import pygame
import sys

# Initialize pygame
pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
PLAYER_SPEED = 5
GRAVITY = 0.5
JUMP_STRENGTH = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Screen setup
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Platformer Game")
clock = pygame.time.Clock()

# Classes
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect(topleft=(x, y))
        self.velocity = pygame.Vector2(0, 0)
        self.on_ground = False

    def update(self, platforms):
        self.velocity.y += GRAVITY
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.velocity.x = -PLAYER_SPEED
        elif keys[pygame.K_RIGHT]:
            self.velocity.x = PLAYER_SPEED
        else:
            self.velocity.x = 0
        
        if keys[pygame.K_SPACE] and self.on_ground:
            self.velocity.y = -JUMP_STRENGTH

        self.rect.x += self.velocity.x
        self.collide(platforms, 'x')
        self.rect.y += self.velocity.y
        self.on_ground = False
        self.collide(platforms, 'y')

    def collide(self, platforms, direction):
        for platform in platforms:
            if self.rect.colliderect(platform.rect):
                if direction == 'x':
                    if self.velocity.x > 0:
                        self.rect.right = platform.rect.left
                    elif self.velocity.x < 0:
                        self.rect.left = platform.rect.right
                    self.velocity.x = 0
                elif direction == 'y':
                    if self.velocity.y > 0:
                        self.rect.bottom = platform.rect.top
                        self.on_ground = True
                    elif self.velocity.y < 0:
                        self.rect.top = platform.rect.bottom
                    self.velocity.y = 0

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(BLACK)
        self.rect = self.image.get_rect(topleft=(x, y))

class MovableObstacle(Platform):
    def __init__(self, x, y, width, height, move_x, move_y):
        super().__init__(x, y, width, height)
        self.initial_position = pygame.Vector2(x, y)
        self.move_vector = pygame.Vector2(move_x, move_y)

    def update(self):
        self.rect.topleft = self.initial_position + pygame.Vector2(
            self.move_vector.x * pygame.math.sin(pygame.time.get_ticks() / 1000),
            self.move_vector.y * pygame.math.cos(pygame.time.get_ticks() / 1000)
        )

# Map building
def create_level():
    platforms = pygame.sprite.Group()
    obstacles = pygame.sprite.Group()

    platforms.add(Platform(0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40))
    platforms.add(Platform(200, 500, 100, 20))
    platforms.add(Platform(400, 400, 100, 20))

    obstacles.add(MovableObstacle(300, 300, 50, 50, 50, 0))
    obstacles.add(MovableObstacle(500, 200, 50, 50, 0, 50))

    return platforms, obstacles

def main():
    player = Player(100, SCREEN_HEIGHT - 100)
    platforms, obstacles = create_level()
    all_sprites = pygame.sprite.Group(player, platforms, obstacles)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        all_sprites.update(platforms)
        screen.fill(WHITE)
        all_sprites.draw(screen)
        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main()
