import tkinter as tk
from openai import openai

class ChatApplication(tk.Tk):
    def __init__(self, openai_api_key):
        super().__init__()

        self.title("OpenAI Chat")
        self.geometry("400x500")

        self.openai_api_key = openai_api_key

        self.create_widgets()

    def create_widgets(self):
        self.message_history = tk.Text(self, wrap=tk.WORD)
        self.message_history.pack(fill=tk.BOTH, expand=True)

        self.message_entry = tk.Entry(self)
        self.message_entry.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

        self.send_button = tk.Button(self, text="Send", command=self.send_message)
        self.send_button.pack(side=tk.RIGHT)

    def send_message(self):
        message = self.message_entry.get().strip()
        if message:
            self.message_history.insert(tk.END, "You: " + message + "\n")
            self.message_entry.delete(0, tk.END)

            reply = self.get_ai_reply(message)
            self.message_history.insert(tk.END, "AI: " + reply + "\n")

    def get_ai_reply(self, message):
        openai.api_key = self.openai_api_key
        response = openai.Completion.create(
            engine="davinci",
            prompt=message,
            max_tokens=50
        )
        return response.choices[0].text.strip()

if __name__ == "__main__":
    openai_api_key = "sk-proj-BppGMucez1f3gn3JsFdzT3BlbkFJRBbFcaDNXOgVA1UwttSd"
    app = ChatApplication(openai_api_key)
    app.mainloop()
